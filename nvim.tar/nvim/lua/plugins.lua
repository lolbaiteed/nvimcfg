-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  local lazyrepo = "https://github.com/folke/lazy.nvim.git"
  local out = vim.fn.system({ "git", "clone", "--filter=blob:none", "--branch=stable", lazyrepo, lazypath })
  if vim.v.shell_error ~= 0 then
    vim.api.nvim_echo({
      { "Failed to clone lazy.nvim:\n", "ErrorMsg" },
      { out, "WarningMsg" },
      { "\nPress any key to exit..." },
    }, true, {})
    vim.fn.getchar()
    os.exit(1)
  end
end
vim.opt.rtp:prepend(lazypath)

-- Make sure to setup `mapleader` and `maplocalleader` before
-- loading lazy.nvim so that mappings are correct.
-- This is also a good place to setup other settings (vim.opt)
vim.g.mapleader = " "
vim.g.maplocalleader = "\\"

-- Setup lazy.nvim
require("lazy").setup({
	{ "nvim-treesitter/nvim-treesitter",
	config = function()
	require("nvim-treesitter.configs").setup({
	ensure_installed = {"c", "lua", "vim", "vimdoc", "asm", "rust", "zig", "go"},

	auto_install = false,

	highlight = { enable = true, },
	incremental_selection = {
		enable = true,
		keymaps = {
		init_selection = "<Leader>ss",
		node_incremental = "<Leader>si",
		scope_incremental = "<Leader>sc",
		node_decremental = "<Leader>sd",
		},
	     },
          })
	end,
      },
      { "williamboman/mason.nvim",
	config = function()
		require("masoncfg")
	end},
       {"williamboman/mason-lspconfig.nvim"}, 
       {"neovim/nvim-lspconfig",
	config = function()
		local lspconfig = require("lspconfig")
		lspconfig.clangd.setup({})
		lspconfig.rust_analyzer.setup({})
		lspconfig.asm_lsp.setup({})
		lspconfig.zls.setup({})
		lspconfig.gopls.setup({})
	end	
      },
      { "nvim-telescope/telescope.nvim", tag = "0.1.8",
	config = function()
		require("telescopecfg")
	end},
      { "paretje/nvim-man" },
      { "hrsh7th/cmp-nvim-lsp" },
      { "hrsh7th/cmp-buffer" },
      { "hrsh7th/cmp-path" },
      { "hrsh7th/cmp-cmdline" },
      { "hrsh7th/nvim-cmp", config = function() require("cmpcfg") end },
      { "L3MON4D3/LuaSnip",
		dependencies = { "saadparwaiz1/cmp_luasnip", "rafamadriz/friendly-snippets" },
      },
      { "sainnhe/gruvbox-material", config = function() vim.cmd.colorscheme("gruvbox-material") end },
      { "epwalsh/obsidian.nvim", config = function() require("obsidcfg") end },
})
