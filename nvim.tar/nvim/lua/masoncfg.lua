require("mason").setup()
require("mason-lspconfig").setup()
